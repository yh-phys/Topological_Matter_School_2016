#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Author:  Dominik Gresch <greschd@gmx.ch>
# Date:    22.08.2016 09:05:03 CEST
# File:    square_lattice.py

import logging
import itertools

import z2pack
import tbmodels
import matplotlib.pyplot as plt

logging.getLogger('z2pack').setLevel(logging.WARNING)

def get_model(t1, t2):
    model = tbmodels.Model(
        on_site=(1, 1, -1, -1), 
        pos=[
            [0., 0., 0.], 
            [0., 0., 0.], 
            [0.5, 0.5, 0.], 
            [0.5, 0.5, 0.]
        ],
        occ=2
    )

    for p, R in zip([1, 1j, -1j, -1], itertools.product([0, -1], [0, -1], [0])):
        model.add_hop(overlap=p * t1, orbital_1=0, orbital_2=2, R=R)
        model.add_hop(overlap=p.conjugate() * t1, orbital_1=1, orbital_2=3, R=R)

    for R in ((r[0], r[1], 0) for r in itertools.permutations([0, 1])):
        model.add_hop(t2, 0, 0, R)
        model.add_hop(t2, 1, 1, R)
        model.add_hop(-t2, 2, 2, R)
        model.add_hop(-t2, 3, 3, R)
    return model

def run(t1, t2, name):
    system = z2pack.tb.System(get_model(t1, t2))
    result = z2pack.surface.run(
        system=system, 
        surface=lambda s, t: [t, s / 2, 0]    
    )
    print(
        'Z2 invariant for t1={}, t2={} :'.format(t1, t2), 
        z2pack.invariant.z2(result)
    )
    z2pack.plot.wcc(result)
    plt.show()
    
if __name__ == '__main__':
    run(0.1, 0.2, 'plot_1')
    run(0.2, 0.3, 'plot_2')
