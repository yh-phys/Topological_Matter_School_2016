#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Author:  Dominik Gresch <greschd@gmx.ch>
# Date:    19.08.2016 23:56:43 CEST
# File:    mote2.py

import z2pack
import tbmodels
import scipy.optimize as so
import matplotlib.pyplot as plt

model = tbmodels.Model.from_hr_file('data/wannier90_hr.dat')
system = z2pack.tb.System(model, bands=56)


def run(surface, name, **settings):
    result = z2pack.surface.run(
        system=system,
        surface=surface,
        save_file='results/{}.msgpack'.format(name),
        load=True,
        **settings
    )
    print(
        'Z2 invariant for {}:'.format(name),
        z2pack.invariant.z2(result)
    )
    fig, ax = plt.subplots()
    z2pack.plot.wcc(result, axis=ax)
    plt.savefig('plots/{}.pdf'.format(name))

def run2(surface, name, **settings):
    try:
        init_result = z2pack.io.load(
            'results/{}.msgpack'.format(name)
        )
    except OSError:
        init_result = None
    result = z2pack.surface.run(
        system=system,
        surface=surface,
        init_result=init_result,
        **settings
    )
    z2pack.io.save(result, 'results/{}.msgpack'.format(name))
    print(
        'Z2 invariant for {}:'.format(name),
        z2pack.invariant.z2(result)
    )
    fig, ax = plt.subplots()
    z2pack.plot.wcc(result, axis=ax)
    plt.savefig('plots/{}.pdf'.format(name))
    
def gap(k):
    eig = model.eigenval(k)
    return eig[56] - eig[55]

if __name__ == '__main__':
    # Task a)
    run(lambda t1, t2: [t1 / 2, 0, t2], 'y0')
    
    # Task b)
    run2(lambda t1, t2: [t1 / 2, 0, t2], 'y0', num_lines=201, min_neighbour_dist=1e-6, iterator=range(8, 41, 2))

    # Task c)
    run2(lambda t1, t2: [t1 / 2, t2, 0], 'z0', min_neighbour_dist=1e-6, iterator=range(8, 81, 2))
    
    # Task d)
    guess = so.minimize(gap, x0=[0.9, 0.05, 0])
    result = z2pack.surface.run(
        system=system,
        surface=z2pack.shape.Sphere(guess.x, 0.05),
        iterator=range(20, 101, 2),
        min_neighbour_dist=1e-6
    )
    z2pack.plot.chern(result)
    plt.savefig('plots/weyl_chern.pdf')
    print(
        'Chern number on a Sphere around the point', 
        guess.x, 
        ':', 
        z2pack.invariant.chern(result)
    )
    
    
