#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Author:  Dominik Gresch <greschd@gmx.ch>
# Date:    16.08.2016 14:25:39 CEST
# File:    haldane.py

import json
import logging

import z2pack
import numpy as np
import matplotlib.pyplot as plt

logging.getLogger('z2pack').setLevel(logging.WARNING)

# defining pauli matrices
identity = np.identity(2, dtype=complex)
pauli_x = np.array([[0, 1], [1, 0]], dtype=complex)
pauli_y = np.array([[0, -1j], [1j, 0]], dtype=complex)
pauli_z = np.array([[1, 0], [0, -1]], dtype=complex)


def Hamilton(k, m, t1, t2, phi):
    kx, ky, _ = k
    k_a = 2 * np.pi / 3. * np.array([kx + ky, -2. * kx + ky, kx - 2. * ky])
    k_b = 2 * np.pi * np.array([-kx + ky, -ky, kx])
    H = 2 * t2 * np.cos(phi) * sum(np.cos(k_b)) * identity
    H += t1 * sum(np.cos(k_a)) * pauli_x
    H += t1 * sum(np.sin(k_a)) * pauli_y
    H += m * pauli_z
    H -= 2 * t2 * np.sin(phi) * sum(np.sin(k_b)) * pauli_z
    return H

def get_chern(m, t1, t2, phi, **settings):
    system = z2pack.hm.System(lambda k: Hamilton(k, m, t1, t2, phi), bands=1)
    
    result = z2pack.surface.run(system=system, surface=lambda s, t: [t, s, 0.], **settings)
    return z2pack.invariant.chern(result)


if __name__ == "__main__":
    # Task a)
    print(get_chern(0.5, 1., 1. / 3., 0.5 * np.pi))
    print(get_chern(0.5, 1., 1. / 3., -0.5 * np.pi))

    # Task b)
    print(get_chern(1.7, 1., 1. / 3., 0.5 * np.pi, min_neighbour_dist=1e-4))
    print(get_chern(1.7, 1., 1. / 3., -0.5 * np.pi, min_neighbour_dist=1e-4))

    # Task c) (optional - for advanced Python users)
    save_file = 'results/phases.json'
    try:
        with open(save_file, 'r') as f:
            phase_result = json.load(f)
    except FileNotFoundError:
        t1 = 1.
        t2 = 1 / 3
        M_list = np.linspace(-2, 2, 101)
        phi_list = np.linspace(-np.pi, np.pi, 101)
        
        phase_result = [
            [get_chern(M, t1, t2, phi, min_neighbour_dist=1e-5, iterator=range(8, 61, 2)) for phi in phi_list]
            for M in M_list
        ]
        with open(save_file, 'w') as f:
            json.dump(phase_result, f)
            
    plt.set_cmap('RdBu')
    fig, ax = plt.subplots(figsize=[5, 3])
    mappable = ax.imshow(phase_result, interpolation='none', origin='lower', aspect=0.5)
    ax.set_xticks([0, 100])
    ax.set_yticks([0, 100])
    ax.set_xticklabels([r'$-\pi$', r'$\pi$'])
    ax.set_yticklabels([r'$-6$', r'$6$'])
    ax.set_xlabel(r'$\phi$')
    ax.set_ylabel(r'$M / t_2$', rotation='horizontal')
    fig.colorbar(mappable, ticks=[-1, 0, 1], boundaries=[-1.5, -1 / 2, 1 / 2, 1.5,], shrink=0.65, drawedges=True)
    plt.savefig('plots/phases.pdf', bbox_inches='tight')
    
