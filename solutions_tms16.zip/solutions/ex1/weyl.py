#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Author:  Dominik Gresch <greschd@gmx.ch>
# Date:    16.08.2016 14:56:31 CEST
# File:    weyl.py

import logging

import z2pack
import numpy as np
import matplotlib.pyplot as plt

# suppressing the non-critical output
logging.getLogger('z2pack').setLevel(logging.WARNING)

# defining the Weyl Hamiltonian
def Hamilton(k):
    kx, ky, kz = k
    return np.array([
        [kz, kx -1j * ky],
        [kx + 1j * ky, -kz]
    ])

# creating the system for the Weyl Hamiltonian
system = z2pack.hm.System(Hamilton)
# running the surface calculation on a Sphere
result = z2pack.surface.run(
    system=system,
    surface=z2pack.shape.Sphere([0., 0., 0.], 0.1)
)
# printing the Chern number
print('The Chern number on the Sphere is ', z2pack.invariant.chern(result))

# creating the plot
fig, ax = plt.subplots(figsize=[4, 4])
z2pack.plot.chern(result, axis=ax)
# changing the axes labels and ticks
ax.set_xticks([0, 1])
ax.set_yticks([0, 1])
ax.set_xticklabels([r'$-\pi$', r'$0$'])
ax.set_yticklabels([0, 1])
ax.set_xlabel(r'$\theta$')
ax.set_ylabel(r'$\bar{\varphi}$', rotation='horizontal')
# saving the plot
plt.savefig('weyl_chern.pdf', bbox_inches='tight')
