#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np

# defining pauli matrices
identity = np.identity(2, dtype=complex)
pauli_x = np.array([[0, 1], [1, 0]], dtype=complex)
pauli_y = np.array([[0, -1j], [1j, 0]], dtype=complex)
pauli_z = np.array([[1, 0], [0, -1]], dtype=complex)

# defining the Weyl Hamiltonian
def Hamilton(k):
    kx, ky, kz = k
    return kx * pauli_x + ky * pauli_y + kz * pauli_z
