#!/usr/bin/env python
# -*- coding: utf-8 -*-

import itertools

import tbmodels

def get_model(t1, t2):
    model = tbmodels.Model(
        on_site=(1, 1, -1, -1), 
        pos=[
            [0., 0., 0.], 
            [0., 0., 0.], 
            [0.5, 0.5, 0.], 
            [0.5, 0.5, 0.]
        ],
        occ=2
    )

    for p, R in zip([1, 1j, -1j, -1], itertools.product(
            [0, -1], [0, -1], [0]
        )):
        model.add_hop(
            overlap=p * t1, 
            orbital_1=0, 
            orbital_2=2, 
            R=R
        )
        model.add_hop(
            overlap=p.conjugate() * t1, 
            orbital_1=1, 
            orbital_2=3, 
            R=R
        )

    for R in ((r[0], r[1], 0) for r in itertools.permutations(
        [0, 1]
    )):
        model.add_hop(t2, 0, 0, R)
        model.add_hop(t2, 1, 1, R)
        model.add_hop(-t2, 2, 2, R)
        model.add_hop(-t2, 3, 3, R)
    return model

def run(t1, t2):
    # Task a: print the Z2 invariant for the kz=0 plane
    
    # Task b: create a plot showing WCC and the largest gap
    
if __name__ == '__main__':
    # Call the run function here
